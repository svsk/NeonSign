http://media.sverr.es/2015-04-02_1350.png

The image in the link has three arrows.
Starting from the top:
Arrow #1 points to something called RunInterval. This can be changed to whatever you choose. It designates how often the chat message should be sent in seconds. Remember the decimal.
Arrow #2 points to something called IsEnabled. Set this value to true instead of false if you wish for the addon to run at all.
Arrow #3 points to something called RecruitmentMessage. This can be changed to whatever message you wish. It has to be less than 255 characters though I believe. Remember quotation marks.